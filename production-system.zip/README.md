
  # Production Planning System UI

  This is a code bundle for Production Planning System UI. The original project is available at https://www.figma.com/design/LrmKaLaSnKWnrffkzVG6dV/Production-Planning-System-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  